import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ⚠️  بعد ما تنشر التطبيق على Replit، استبدل هذا الرابط
const String kAppUrl = 'https://pharma-arena.replit.app';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF020817),
  ));
  runApp(const PharmaArenaApp());
}

class PharmaArenaApp extends StatelessWidget {
  const PharmaArenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pharma Arena',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF020817),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1991FF),
          brightness: Brightness.dark,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// ─── Splash Screen ──────────────────────────────────────────────
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _scale = Tween<double>(begin: 0.7, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut));
    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const WebViewScreen()),
        );
      }
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020817),
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: ScaleTransition(
            scale: _scale,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1991FF), Color(0xFF0ea5e9)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF1991FF).withOpacity(0.4),
                        blurRadius: 30, spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.medication_liquid_rounded,
                      size: 56, color: Colors.white),
                ),
                const SizedBox(height: 24),
                const Text('Pharma Arena',
                    style: TextStyle(color: Colors.white,
                        fontSize: 30, fontWeight: FontWeight.w800,
                        letterSpacing: -0.5)),
                const SizedBox(height: 8),
                const Text('Master Pharmacology with AI',
                    style: TextStyle(color: Color(0xFF64748B), fontSize: 15)),
                const SizedBox(height: 48),
                const SizedBox(
                  width: 28, height: 28,
                  child: CircularProgressIndicator(
                    color: Color(0xFF1991FF), strokeWidth: 2.5),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── WebView Screen ──────────────────────────────────────────────
class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});
  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _error   = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF020817))
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted:  (_) => setState(() { _loading = true;  _error = false; }),
        onPageFinished: (_) => setState(() => _loading = false),
        onWebResourceError: (_) => setState(() { _loading = false; _error = true; }),
      ))
      ..loadRequest(Uri.parse(kAppUrl));
  }

  void _reload() {
    setState(() { _loading = true; _error = false; });
    _controller.reload();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (await _controller.canGoBack()) _controller.goBack();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF020817),
        body: Stack(
          children: [
            WebViewWidget(controller: _controller),

            // Loading overlay
            if (_loading)
              Container(
                color: const Color(0xFF020817),
                child: const Center(
                  child: CircularProgressIndicator(
                    color: Color(0xFF1991FF), strokeWidth: 2.5),
                ),
              ),

            // Error screen
            if (_error)
              Container(
                color: const Color(0xFF020817),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.wifi_off_rounded,
                            size: 64, color: Color(0xFF64748B)),
                        const SizedBox(height: 20),
                        const Text('No Connection',
                            style: TextStyle(color: Colors.white,
                                fontSize: 22, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        const Text('Check your internet and try again',
                            style: TextStyle(color: Color(0xFF64748B),
                                fontSize: 14),
                            textAlign: TextAlign.center),
                        const SizedBox(height: 32),
                        ElevatedButton.icon(
                          onPressed: _reload,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Try Again'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1991FF),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 32, vertical: 14),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
